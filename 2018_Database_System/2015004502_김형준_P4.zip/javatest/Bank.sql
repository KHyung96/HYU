-- MySQL dump 10.16  Distrib 10.3.10-MariaDB, for osx10.14 (x86_64)
--
-- Host: localhost    Database: Bank
-- ------------------------------------------------------
-- Server version	10.3.10-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Acc_Manage`
--

DROP TABLE IF EXISTS `Acc_Manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Acc_Manage` (
  `AccNum_Acc` char(12) NOT NULL,
  `ManID` int(11) NOT NULL,
  PRIMARY KEY (`AccNum_Acc`,`ManID`),
  KEY `ManID` (`ManID`),
  CONSTRAINT `acc_manage_ibfk_1` FOREIGN KEY (`AccNum_Acc`) REFERENCES `Account` (`AccNum`),
  CONSTRAINT `acc_manage_ibfk_2` FOREIGN KEY (`ManID`) REFERENCES `Manager` (`ManID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Acc_Manage`
--

LOCK TABLES `Acc_Manage` WRITE;
/*!40000 ALTER TABLE `Acc_Manage` DISABLE KEYS */;
INSERT INTO `Acc_Manage` VALUES ('110437100000',1),('110437100000',2),('110437100000',3),('110437100001',1),('110437100001',2),('110437100001',3),('110437100002',1),('110437100002',2),('110437100002',3),('110437100003',1),('110437100003',2),('110437100003',3),('110437100004',1),('110437100004',2),('110437100004',3),('110437100005',1),('110437100005',2),('110437100005',3),('110437100006',1),('110437100006',2),('110437100006',3),('110437100007',1),('110437100007',2),('110437100007',3),('110437100008',1),('110437100008',2),('110437100008',3),('110437100009',1),('110437100009',2),('110437100009',3),('110437100010',1),('110437100010',2),('110437100010',3),('110437100011',1),('110437100011',2),('110437100011',3),('110437100012',1),('110437100012',2),('110437100012',3),('110437100013',1),('110437100013',2),('110437100013',3),('110437100014',1),('110437100014',2),('110437100014',3),('110437100015',1),('110437100015',2),('110437100015',3);
/*!40000 ALTER TABLE `Acc_Manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account` (
  `AccNum` char(12) NOT NULL,
  `AccPwd` varchar(10) NOT NULL,
  `UserSSN` char(13) NOT NULL,
  PRIMARY KEY (`AccNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
INSERT INTO `Account` VALUES ('110437100000','js123','1111111111111'),('110437100001','fw123','2222222222222'),('110437100002','fw123','2222222222222'),('110437100003','jennifer12','4444444444444'),('110437100004','jennifer12','4444444444444'),('110437100005','jennifer12','4444444444444'),('110437100006','jennifer12','4444444444444'),('110437100007','rn123','5555555555555'),('110437100008','rn123','5555555555555'),('110437100009','rn123','5555555555555'),('110437100010','rn123','5555555555555'),('110437100011','rn123','5555555555555'),('110437100012','joyce12','6666666666666'),('110437100013','jb123','8888888888888'),('110437100014','jb123','8888888888888'),('110437100015','jb123','8888888888888');
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bank`
--

DROP TABLE IF EXISTS `Bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bank` (
  `BName` varchar(15) NOT NULL,
  `CorRegNum` char(10) NOT NULL,
  `CEOName` varchar(20) DEFAULT NULL,
  `BankNum` varchar(10) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `WebAdd` varchar(30) DEFAULT NULL,
  `BankCapital` int(11) NOT NULL,
  PRIMARY KEY (`CorRegNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bank`
--

LOCK TABLES `Bank` WRITE;
/*!40000 ALTER TABLE `Bank` DISABLE KEYS */;
INSERT INTO `Bank` VALUES ('Bank of America','1234567890','Brian Moynihan','2816683101','13331 TX-249, Houston, TX','boa@bank.com','https://www.bankofamerica.com/',2000000000);
/*!40000 ALTER TABLE `Bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Card`
--

DROP TABLE IF EXISTS `Card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Card` (
  `CardNum` char(16) NOT NULL,
  `AccNum` char(12) NOT NULL,
  `CardLim` int(11) DEFAULT NULL,
  `CVCNum` char(3) NOT NULL,
  `ValDate` char(4) NOT NULL,
  PRIMARY KEY (`CardNum`),
  KEY `AccNum` (`AccNum`),
  CONSTRAINT `card_ibfk_1` FOREIGN KEY (`AccNum`) REFERENCES `Account` (`AccNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Card`
--

LOCK TABLES `Card` WRITE;
/*!40000 ALTER TABLE `Card` DISABLE KEYS */;
INSERT INTO `Card` VALUES ('1000100110021003','110437100000',10000000,'012','1228'),('1004100510061007','110437100001',10000000,'123','1028'),('1008100910101011','110437100005',10000000,'234','0128'),('1012101310141015','110437100009',10000000,'345','0526'),('1016101710181019','110437100012',10000000,'456','1020'),('1020102110221023','110437100014',10000000,'567','1124');
/*!40000 ALTER TABLE `Card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DealInfo`
--

DROP TABLE IF EXISTS `DealInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DealInfo` (
  `AccNum` char(12) NOT NULL,
  `DealDate` date NOT NULL,
  `DealAccNum` char(12) NOT NULL,
  `DealMoney` int(11) NOT NULL,
  PRIMARY KEY (`AccNum`,`DealDate`),
  CONSTRAINT `dealinfo_ibfk_1` FOREIGN KEY (`AccNum`) REFERENCES `Account` (`AccNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DealInfo`
--

LOCK TABLES `DealInfo` WRITE;
/*!40000 ALTER TABLE `DealInfo` DISABLE KEYS */;
INSERT INTO `DealInfo` VALUES ('110437100000','2018-12-01','110437100010',100000),('110437100000','2018-12-03','110437100007',1000),('110437100001','2018-12-01','110437100005',50000),('110437100007','2018-12-03','110437100000',1000),('110437100014','2018-12-02','110437100012',10000);
/*!40000 ALTER TABLE `DealInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LoanInfo`
--

DROP TABLE IF EXISTS `LoanInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LoanInfo` (
  `AccNum` char(12) NOT NULL,
  `UserSSN` char(13) DEFAULT NULL,
  `UserCredRat` int(11) DEFAULT NULL,
  `LoanMoney` int(11) NOT NULL,
  `BCorRegNum` char(10) NOT NULL,
  PRIMARY KEY (`AccNum`),
  KEY `BCorRegNum` (`BCorRegNum`),
  CONSTRAINT `loaninfo_ibfk_1` FOREIGN KEY (`BCorRegNum`) REFERENCES `Bank` (`CorRegNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LoanInfo`
--

LOCK TABLES `LoanInfo` WRITE;
/*!40000 ALTER TABLE `LoanInfo` DISABLE KEYS */;
INSERT INTO `LoanInfo` VALUES ('110437100004','4444444444444',1,10000000,'1234567890'),('110437100010','5555555555555',1,5000000,'1234567890');
/*!40000 ALTER TABLE `LoanInfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Manager`
--

DROP TABLE IF EXISTS `Manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Manager` (
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `ManID` int(11) NOT NULL,
  `SSN` char(13) NOT NULL,
  `Sex` char(1) DEFAULT NULL,
  `BCorRegNum` char(10) NOT NULL,
  PRIMARY KEY (`ManID`),
  KEY `BCorRegNum` (`BCorRegNum`),
  CONSTRAINT `manager_ibfk_1` FOREIGN KEY (`BCorRegNum`) REFERENCES `Bank` (`CorRegNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Manager`
--

LOCK TABLES `Manager` WRITE;
/*!40000 ALTER TABLE `Manager` DISABLE KEYS */;
INSERT INTO `Manager` VALUES ('Stenson','Palmer',1,'1111112222222','M','1234567890'),('James','English',2,'3333334444444','M','1234567890'),('Stone','Harris',3,'5555556666666','F','1234567890');
/*!40000 ALTER TABLE `Manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Mon_Manage`
--

DROP TABLE IF EXISTS `Mon_Manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Mon_Manage` (
  `AccNum_Mon` char(12) NOT NULL,
  `ManID` int(11) NOT NULL,
  PRIMARY KEY (`AccNum_Mon`,`ManID`),
  KEY `ManID` (`ManID`),
  CONSTRAINT `mon_manage_ibfk_1` FOREIGN KEY (`AccNum_Mon`) REFERENCES `Money` (`AccNum`),
  CONSTRAINT `mon_manage_ibfk_2` FOREIGN KEY (`ManID`) REFERENCES `Manager` (`ManID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Mon_Manage`
--

LOCK TABLES `Mon_Manage` WRITE;
/*!40000 ALTER TABLE `Mon_Manage` DISABLE KEYS */;
INSERT INTO `Mon_Manage` VALUES ('110437100000',1),('110437100000',2),('110437100000',3),('110437100001',1),('110437100001',2),('110437100001',3),('110437100002',1),('110437100002',2),('110437100002',3),('110437100003',1),('110437100003',2),('110437100003',3),('110437100004',1),('110437100004',2),('110437100004',3),('110437100005',1),('110437100005',2),('110437100005',3),('110437100006',1),('110437100006',2),('110437100006',3),('110437100007',1),('110437100007',2),('110437100007',3),('110437100008',1),('110437100008',2),('110437100008',3),('110437100009',1),('110437100009',2),('110437100009',3),('110437100010',1),('110437100010',2),('110437100010',3),('110437100011',1),('110437100011',2),('110437100011',3),('110437100012',1),('110437100012',2),('110437100012',3),('110437100013',1),('110437100013',2),('110437100013',3),('110437100014',1),('110437100014',2),('110437100014',3),('110437100015',1),('110437100015',2),('110437100015',3);
/*!40000 ALTER TABLE `Mon_Manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Money`
--

DROP TABLE IF EXISTS `Money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Money` (
  `AccNum` char(12) NOT NULL,
  `Balance` int(11) NOT NULL,
  `LoanMoney` int(11) DEFAULT NULL,
  PRIMARY KEY (`AccNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Money`
--

LOCK TABLES `Money` WRITE;
/*!40000 ALTER TABLE `Money` DISABLE KEYS */;
INSERT INTO `Money` VALUES ('110437100000',498000,0),('110437100001',1000000,0),('110437100002',750000,0),('110437100003',50000,0),('110437100004',50000000,10000000),('110437100005',1000000,0),('110437100006',500000,0),('110437100007',12000,0),('110437100008',100000,0),('110437100009',1000000,0),('110437100010',10000000,5000000),('110437100011',50000,0),('110437100012',1000000,0),('110437100013',100000,0),('110437100014',500000,0),('110437100015',10000,0);
/*!40000 ALTER TABLE `Money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NumOfAcc`
--

DROP TABLE IF EXISTS `NumOfAcc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NumOfAcc` (
  `UserSSN` char(13) NOT NULL,
  `NumOfAcc` int(11) NOT NULL,
  PRIMARY KEY (`UserSSN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NumOfAcc`
--

LOCK TABLES `NumOfAcc` WRITE;
/*!40000 ALTER TABLE `NumOfAcc` DISABLE KEYS */;
INSERT INTO `NumOfAcc` VALUES ('1111111111111',1),('2222222222222',2),('4444444444444',4),('5555555555555',5),('6666666666666',1),('8888888888888',3);
/*!40000 ALTER TABLE `NumOfAcc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Num_Acc_Manage`
--

DROP TABLE IF EXISTS `Num_Acc_Manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Num_Acc_Manage` (
  `UserSSN` char(13) NOT NULL,
  `ManID` int(11) NOT NULL,
  PRIMARY KEY (`UserSSN`,`ManID`),
  KEY `ManID` (`ManID`),
  CONSTRAINT `num_acc_manage_ibfk_1` FOREIGN KEY (`UserSSN`) REFERENCES `NumOfAcc` (`UserSSN`),
  CONSTRAINT `num_acc_manage_ibfk_2` FOREIGN KEY (`ManID`) REFERENCES `Manager` (`ManID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Num_Acc_Manage`
--

LOCK TABLES `Num_Acc_Manage` WRITE;
/*!40000 ALTER TABLE `Num_Acc_Manage` DISABLE KEYS */;
INSERT INTO `Num_Acc_Manage` VALUES ('1111111111111',1),('1111111111111',2),('1111111111111',3),('2222222222222',1),('2222222222222',2),('2222222222222',3),('4444444444444',1),('4444444444444',2),('4444444444444',3),('5555555555555',1),('5555555555555',2),('5555555555555',3),('6666666666666',1),('6666666666666',2),('6666666666666',3),('8888888888888',1),('8888888888888',2),('8888888888888',3);
/*!40000 ALTER TABLE `Num_Acc_Manage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `SSN` char(13) NOT NULL,
  `Sex` char(1) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `ManID` int(11) NOT NULL,
  PRIMARY KEY (`SSN`),
  KEY `ManID` (`ManID`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`ManID`) REFERENCES `Manager` (`ManID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES ('John','Smilth','1111111111111','M','asdf@bank.com','751 Fondren, Houston, TX',1),('Franklin','Wong','2222222222222','M','bbbb@bank.com','638 Voss, Houston, TX',2),('Alicia','Zelaya','3333333333333','F','cccc@bank.com','3321 Castle, Spring, TX',3),('Jennifer','Wallace','4444444444444','F','dddd@bank.com','291 Berry, Bellaire, TX',1),('Ramesh','Narayan','5555555555555','M','eeee@bank.com','975 Fire Oak, Humble, TX',2),('Joyce','English','6666666666666','F','ffff@bank.com','5631 Rice, Houston, TX',3),('Ahmad','Jabbar','7777777777777','M','gggg@bank.com','980 Dallas, Houston, TX',1),('James','Borg','8888888888888','M','hhhh@bank.com','450 Stone, Houston, TX',2);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User_Man_Manage`
--

DROP TABLE IF EXISTS `User_Man_Manage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User_Man_Manage` (
  `UserSSN` char(13) NOT NULL,
  `ManID` int(11) NOT NULL,
  PRIMARY KEY (`UserSSN`,`ManID`),
  KEY `ManID` (`ManID`),
  CONSTRAINT `user_man_manage_ibfk_1` FOREIGN KEY (`UserSSN`) REFERENCES `User` (`SSN`),
  CONSTRAINT `user_man_manage_ibfk_2` FOREIGN KEY (`ManID`) REFERENCES `Manager` (`ManID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_Man_Manage`
--

LOCK TABLES `User_Man_Manage` WRITE;
/*!40000 ALTER TABLE `User_Man_Manage` DISABLE KEYS */;
INSERT INTO `User_Man_Manage` VALUES ('1111111111111',1),('1111111111111',2),('1111111111111',3),('2222222222222',1),('2222222222222',2),('2222222222222',3),('3333333333333',1),('3333333333333',2),('3333333333333',3),('4444444444444',1),('4444444444444',2),('4444444444444',3),('5555555555555',1),('5555555555555',2),('5555555555555',3),('6666666666666',1),('6666666666666',2),('6666666666666',3),('7777777777777',1),('7777777777777',2),('7777777777777',3),('8888888888888',1),('8888888888888',2),('8888888888888',3);
/*!40000 ALTER TABLE `User_Man_Manage` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-04 15:04:37
