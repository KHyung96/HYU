import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Bank {
	
	public static final int numOfAccLim = 5;
	
	public static void firstCommands () {
		System.out.println("   bank : Bank information");
		System.out.println("   show : Show informations about your account");
		System.out.println("   deal : Deal with other account");
		System.out.println("   loan : Loan from bank");
		System.out.println("   make : Make new account or card");
		System.out.println(" delete : Delete your account or card");
		System.out.println(" change : Change your information (you can join or quit)");
		System.out.println("   view : View the database with manager privileges");
		System.out.println("   help : Print all commands again");
		System.out.println("   exit : Finish application");
	}
	
	public static void showCommands() {
		System.out.println(" info : Show your information");
		System.out.println("  bal : Show your all account's balance");
		System.out.println(" deal : Show your deals which have traded on particular day");
		System.out.println(" card : Show your cards information");
		System.out.println(" loan : Show your loan status");
		System.out.println("  man : Show your manager's information");
		System.out.println(" help : Print all commands again");
		System.out.println(" back : Back to previous menu");
		System.out.println(" exit : Finish application");
	}
	
	public static void dealCommands() {
		System.out.println("  deposit : Deposit to your account");
		System.out.println(" withdraw : Withdraw from your account");
		System.out.println(" transfer : Transfer to other account");
		System.out.println("     help : Print all commands again");
		System.out.println("     back : Back to previous menu");
		System.out.println("     exit : Finish application");
	}
	
	public static void loanCommands() {
		System.out.println(" loan : Loan from bank");
		System.out.println(" help : Print all commands again");
		System.out.println(" back : Back to previous menu");
		System.out.println(" exit : Finish application");
	}
	
	public static void makeCommands() {
		System.out.println("  acc : Make new account");
		System.out.println(" card : Make new card");
		System.out.println(" help : Print all commands again");
		System.out.println(" back : Back to previous menu");
		System.out.println(" exit : Finish application");
	}
	
	public static void deleteCommands() {
		System.out.println("  acc : Delete your account");
		System.out.println(" card : Delete your card");
		System.out.println(" help : Print all commands again");
		System.out.println(" back : Back to previous menu");
		System.out.println(" exit : Finish application");
	}
	
	public static void changeCommands() {
		System.out.println(" chadd : Change my address");
		System.out.println("  chem : Change my email");
		System.out.println("  join : Join in bank");
		System.out.println("  quit : Quit from bank");
		System.out.println("  help : Print all commands again");
		System.out.println("  back : Back to previous menu");
		System.out.println("  exit : Finish application");
	}
	
	public static void viewCommands() {
		System.out.println("    users : View informations about all users");
		System.out.println(" loaninfo : View informations about loan of each user");
		System.out.println(" dealinfo : View informations about deal which have traded on particular day");
		System.out.println(" numofacc : View informations about each user's number of accounts");
		System.out.println("     help : Print all commands again");
		System.out.println("     back : Back to previous menu");
		System.out.println("     exit : Finish application");
	}
	
	public static void main (String[] args) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null, rs2 = null;
		Scanner keyboard = null;
		String cmd,ssn,acc,acc1,acc2,pwd,pwdch,card,cvc,add,email,fname,lname,sex,date;
		boolean fin = true, end;
		int i,temp,mon,bank_cap,loan_mon,manID,numOfAcc,totalMon,acc_bal;

		try {
			Class.forName("org.mariadb.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","junsmilevv","khj37151A!");
			stmt = con.createStatement();
			keyboard = new Scanner(System.in);
			firstCommands();
			while(fin) {
				System.out.print("Maria DB [Bank] > ");
				cmd = keyboard.nextLine();
				switch (cmd) {
				
					case "bank":
						rs = stmt.executeQuery("select * from Bank");
						rs.next();
						System.out.println("--------------- This Bank's Information ---------------");
						System.out.printf("|     Bank Name     |  %30s |\n",rs.getString(1));
						System.out.printf("|      CEO Name     |  %30s |\n",rs.getString(3));
						System.out.printf("|    Bank Number    |  %30s |\n",rs.getString(4));
						System.out.printf("|   Email Address   |  %30s |\n",rs.getString(6));
						System.out.printf("|    Bank Address   |  %30s |\n",rs.getString(5));
						System.out.printf("|     Web Address   |  %30s |\n",rs.getString(7));
						System.out.printf("| Cor Regist Number |  %30s |\n",rs.getString(2));
						System.out.println("-------------------------------------------------------");
						break;
				
					case "show":
						showCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] Show > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "info":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("-------------------------------------------------------Your Information-------------------------------------------------------");
									System.out.println("| First Name |   Last Name   |      SSN      | Sex |               Address               |               Email               |");
									System.out.println("------------------------------------------------------------------------------------------------------------------------------");
									rs = stmt.executeQuery("select * from User where SSN=" + ssn);
									while (rs.next()) {
										System.out.printf("| %10s | %13s | %13s | %3s | %35s | %33s |\n",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(6),rs.getString(5));
									}
									System.out.println("------------------------------------------------------------------------------------------------------------------------------");
									break;
								case "bal":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("----------------------------------");
									System.out.println("|  Account Number  |   Balance   |");
									System.out.println("----------------------------------");
									rs = stmt.executeQuery("select A.AccNum,M.Balance from Account as A,Money as M where A.AccNum=M.AccNum and A.UserSSN=" + ssn + " order by A.AccNum");
									while (rs.next()) {
										System.out.printf("| %16s | %11s |\n",rs.getString(1),rs.getString(2));
									}
									rs = stmt.executeQuery("select count(A.AccNum),sum(M.Balance) from Account as A,Money as M where A.AccNum=M.AccNum and A.UserSSN=" + ssn);
									rs.next();
									System.out.println("----------------------------------");
									System.out.printf("|  Total Account   | %11s |\n",rs.getString(1));
									System.out.println("----------------------------------");
									System.out.printf("|  Total Balance   | %11s |\n",rs.getString(2));
									System.out.println("----------------------------------");
									break;
								case "deal":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.print("Enter the deal date (YYYY-MM-DD) : ");
									date = keyboard.nextLine();
									System.out.println("--------------------- " + date + " Deal --------------------");
									System.out.println("| Your Account Number | Deal Account Number | Deal Money |");
									System.out.println("----------------------------------------------------------");
									rs = stmt.executeQuery("select A.AccNum,D.DealAccNum,D.DealMoney from Account as A,DealInfo as D where A.AccNum=D.AccNum and A.UserSSN=" + ssn + " and D.DealDate='" + date + "' order by A.AccNum,D.DealAccNum");
									while (rs.next()) {
										System.out.printf("| %19s | %19s | %10s |\n",rs.getString(1),rs.getString(2),rs.getString(3));
									}
									System.out.println("----------------------------------------------------------");
									break;
								case "card":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("----------------------------------------------------------------");
									System.out.println("| Account Number |    Card Number    | CVC Number | Valid Date |");
									System.out.println("----------------------------------------------------------------");
									rs = stmt.executeQuery("select A.AccNum,C.CardNum,C.CVCNum,C.ValDate from Account as A,Card as C where A.AccNum=C.AccNum and A.UserSSN=" + ssn + " order by A.AccNum");
									while (rs.next()) {
										System.out.printf("| %14s | %17s | %10s | %10s |\n",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
									}
									System.out.println("----------------------------------------------------------------\n");
									System.out.println("------------------------------------");
									System.out.println("| Account Number | Number Of Cards |");
									System.out.println("------------------------------------");
									rs = stmt.executeQuery("select A.AccNum,count(A.AccNum) from Account as A,Card as C where A.AccNum=C.AccNum and A.UserSSN=" + ssn + " group by A.AccNum order by A.AccNum");
									while (rs.next()) {
										System.out.printf("| %14s | %15s |\n",rs.getString(1),rs.getString(2));
									}
									System.out.println("------------------------------------");
									break;
								case "loan":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("-----------------------------------");
									System.out.println("| Account Number | Amount of Loan |");
									System.out.println("-----------------------------------");
									rs = stmt.executeQuery("select AccNum,LoanMoney from LoanInfo where UserSSN=" + ssn + " order by AccNum");
									while (rs.next()) {
										System.out.printf("| %14s | %14s |\n",rs.getString(1),rs.getString(2));
									}
									rs = stmt.executeQuery("select sum(LoanMoney) from LoanInfo where UserSSN=" + ssn);
									rs.next();
									System.out.println("-----------------------------------");
									System.out.printf("|  Total Amount  | %14s |\n",rs.getString(1));
									System.out.println("-----------------------------------");
									break;
								case "man":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("-----Your Manager's Information-----");
									System.out.println("| First Name |   Last Name   | Sex |");
									System.out.println("------------------------------------");
									rs = stmt.executeQuery("select M.FName,M.LName,M.Sex from User as U,Manager as M where U.ManID=M.ManID and U.SSN=" + ssn);
									rs.next();
									System.out.printf("| %10s | %13s | %3s |\n",rs.getString(1),rs.getString(2),rs.getString(3));
									System.out.println("------------------------------------");
									break;
								case "help":
									showCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "deal":
						dealCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] Deal > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "deposit":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number : ");
									acc = keyboard.nextLine();
									System.out.print("Enter your account password : ");
									pwd = keyboard.nextLine();
									System.out.print("Enter the amount of money to deposit : ");
									mon = Integer.parseInt(keyboard.nextLine());
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select Balance from Money where AccNum=" + acc);
									rs.next();
									acc_bal = rs.getInt(1);
									acc_bal += mon;
									stmt.executeUpdate("update Money set Balance=" + acc_bal + " where AccNum=" + acc);
									System.out.println("Done!");
									break;
								case "withdraw":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number : ");
									acc = keyboard.nextLine();
									System.out.print("Enter your account password : ");
									pwd = keyboard.nextLine();
									System.out.print("Enter the amount of money to withdraw : ");
									mon = Integer.parseInt(keyboard.nextLine());
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select Balance from Money where AccNum=" + acc);
									rs.next();
									acc_bal = rs.getInt(1);
									if(acc_bal < mon) {
										System.out.println("There is not enough Balance!");
										break;
									}
									acc_bal -= mon;
									stmt.executeUpdate("update Money set Balance=" + acc_bal + " where AccNum=" + acc);
									System.out.println("Done!");
									break;
								case "transfer":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number : ");
									acc1 = keyboard.nextLine();
									System.out.print("Enter your account password : ");
									pwd = keyboard.nextLine();
									System.out.print("Enter the account number to transfer : ");
									acc2 = keyboard.nextLine();
									System.out.print("Enter the amount of money to transfer : ");
									mon = Integer.parseInt(keyboard.nextLine());
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc1 + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc2);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select Balance from Money where AccNum=" + acc1);
									rs.next();
									int acc_bal1 = rs.getInt(1);
									if(acc_bal1 < mon) {
										System.out.println("There is not enough Balance!");
										break;
									}
									acc_bal1 -= mon;
									rs = stmt.executeQuery("select Balance from Money where AccNum=" + acc2);
									rs.next();
									int acc_bal2 = rs.getInt(1);
									acc_bal2 += mon;
									SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA);
									Date current = new Date();
									stmt.executeUpdate("update Money set Balance=" + acc_bal1 + " where AccNum=" + acc1);
									stmt.executeUpdate("update Money set Balance=" + acc_bal2 + " where AccNum=" + acc2);
									stmt.executeUpdate("set foreign_key_checks=0");
									stmt.executeUpdate("insert into DealInfo values ('" + acc1 + "',\"" + dateFormat.format(current) + "\",'" + acc2 + "','" + mon + "')");
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Done!");
									break;
								case "help":
									dealCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "loan":
						loanCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] Loan > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "loan":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number to loan : ");
									acc = keyboard.nextLine();
									System.out.print("Enter your account password : ");
									pwd = keyboard.nextLine();
									System.out.print("Enter the amount of money to loan : ");
									mon = Integer.parseInt(keyboard.nextLine());
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select BankCapital from Bank");
									rs.next();
									bank_cap = rs.getInt(1);
									if(bank_cap < mon) {
										System.out.println("There is not enough Balance in Bank!");
										break;
									}
									bank_cap -= mon;
									rs = stmt.executeQuery("select LoanMoney from Money where AccNum=" + acc);
									rs.next();
									loan_mon = rs.getInt(1);
									loan_mon += mon;
									stmt.executeUpdate("update Money set LoanMoney=" + loan_mon + " where AccNum=" + acc);
									stmt.executeUpdate("update Bank set BankCapital=" + bank_cap);
									rs = stmt.executeQuery("select CorRegNum from Bank");
									rs.next();
									String crn = rs.getString(1);
									rs = stmt.executeQuery("select count(*) from LoanInfo where AccNum=" + acc);
									rs.next();
									stmt.executeUpdate("set foreign_key_checks=0");
									if(rs.getInt(1) == 0) stmt.executeUpdate("insert into LoanInfo values ('" + acc + "','" + ssn + "','1','" + loan_mon + "','" + crn + "')");
									else stmt.executeUpdate("update LoanInfo set LoanMoney=" + loan_mon + " where AccNum=" + acc);
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Done!");
									break;
								case "help":
									loanCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "make":
						makeCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] Make > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "acc":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your new account password (1 ~ 10 digits number or alphabet) : ");
									pwd = keyboard.nextLine();
									System.out.print("Enter the password again : ");
									pwdch = keyboard.nextLine();
									if(!pwd.equals(pwdch)) {
										System.out.println("Password Error Typing Again!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select NumOfAcc from NumOfAcc where UserSSN=" + ssn);
									rs.next();
									numOfAcc = rs.getInt(1);
									if(numOfAcc == numOfAccLim) {
										System.out.println("You Already have Too many Account!");
										break;
									}
									numOfAcc++;
									acc = "000000000000";
									for(i=100000; i<=999999; i++) {
										acc = "110437";
										acc += i;
										rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc);
										rs.next();
										if(rs.getInt(1) == 0)
											break;
									}
									rs = stmt.executeQuery("select ManID from Manager");
									stmt.executeUpdate("set foreign_key_checks=0");
									while (rs.next()) {
										manID = rs.getInt(1);
										stmt.executeUpdate("insert into Acc_Manage values ('" + acc + "','" + manID + "')");
										stmt.executeUpdate("insert into Mon_Manage values ('" + acc + "','" + manID + "')");
									}
									stmt.executeUpdate("insert into Account values ('" + acc + "','" + pwd + "','" + ssn + "')");
									stmt.executeUpdate("insert into Money values ('" + acc + "','0','0')");
									stmt.executeUpdate("update NumOfAcc set NumOfAcc=" + numOfAcc + " where UserSSN=" + ssn);
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Your new account number is " + acc);
									break;
								case "card":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number to make a new card : ");
									acc = keyboard.nextLine();
									System.out.print("Enter your account password : ");
									pwd = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									card = "";
									Random rnd = new Random();
									temp = 1;
									while (temp == 1) {
										card = "";
										for(i=1; i<=4; i++) {
											temp = rnd.nextInt(9999);
											if(temp < 1000) temp += 1000;
											card += Integer.toString(temp);
										}
										temp = -1;
										rs = stmt.executeQuery("select CardNum from Card");
										while (rs.next()) {
											if(rs.getString(1) == card) {
												temp = 1;
												break;
											}
										}
									}
									temp = rnd.nextInt(999);
									if(temp >= 0 && temp < 10) {
										cvc = "00";
										cvc += temp;
									}
									else if(temp >= 10 && temp < 100) {
										cvc = "0";
										cvc += temp;
									}
									else
										cvc = Integer.toString(temp);
									SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM", Locale.KOREA);
									Date current = new Date();
									String today = dateFormat.format(current);
									int year = Integer.parseInt(today.substring(2,4));
									year += 10;
									int month = Integer.parseInt(today.substring(4,6));
									stmt.executeUpdate("set foreign_key_checks=0");
									stmt.executeUpdate("insert into Card values ('" + card + "','" + acc + "','10000000','" + cvc + "','" + month + year + "')");
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Your new card's information");
									System.out.println("->     Number : " + card);
									System.out.println("->      Limit : " + 10000000);
									System.out.println("-> CVC Number : " + cvc);
									System.out.println("-> Valid Date : " + month + "-" + year);
									break;
								case "help":
									makeCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "delete":
						deleteCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] Delete > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "acc":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number to delete : ");
									acc = keyboard.nextLine();
									System.out.print("Enter your account password : ");
									pwd = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select NumOfAcc from NumOfAcc where UserSSN=" + ssn);
									rs.next();
									numOfAcc = rs.getInt(1);
									numOfAcc--;
									stmt.executeUpdate("set foreign_key_checks=0");
									stmt.executeUpdate("update NumOfAcc set NumOfAcc=" + numOfAcc + " where UserSSN=" + ssn);
									stmt.executeQuery("delete from Money where AccNum=" + acc);
									stmt.executeQuery("delete from Account where AccNum=" + acc);
									stmt.executeQuery("delete from DealInfo where AccNum=" + acc);
									stmt.executeQuery("delete from Card where AccNum=" + acc);
									stmt.executeQuery("delete from Acc_Manage where AccNum_Acc=" + acc);
									stmt.executeQuery("delete from Mon_Manage where AccNum_Mon=" + acc);
									rs = stmt.executeQuery("select LoanMoney from LoanInfo where AccNum=" + acc);
									mon = 0;
									while (rs.next())
										mon += rs.getInt(1);
									rs = stmt.executeQuery("select BankCapital from Bank");
									rs.next();
									bank_cap = rs.getInt(1);
									bank_cap += mon;
									stmt.executeUpdate("update Bank set BankCapital=" + bank_cap);
									stmt.executeUpdate("delete from LoanInfo where AccNum=" + acc);
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Done!");
									break;
								case "card":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your account number connected to the card : ");
									acc = keyboard.nextLine();
									System.out.print("Enter your account password connected to the card : ");
									pwd = keyboard.nextLine();
									System.out.print("Enter your card number to delete : ");
									card = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Account where AccNum=" + acc + " and AccPwd='" + pwd + "'");
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Account Information Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Card where CardNum=" + card);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("Card Information Error!");
										break;
									}
									stmt.executeUpdate("set foreign_key_checks=0");
									stmt.executeQuery("delete from Card where CardNum=" + card);
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Done!");
									break;
								case "help":
									deleteCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "change":
						changeCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] Change > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "chadd":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your new Address : ");
									add = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									stmt.executeQuery("update User set Address=\"" + add + "\" where SSN=" + ssn);
									System.out.println("Done!");
									break;
								case "chem":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your new Email : ");
									email = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									stmt.executeQuery("update User set Email=\"" + email + "\" where SSN=" + ssn);
									System.out.println("Done!");
									break;
								case "join":
									System.out.println("Welcome to join our Bank!");
									System.out.print("Enter your First Name : ");
									fname = keyboard.nextLine();
									System.out.print("Enter your Last Name : ");
									lname = keyboard.nextLine();
									System.out.print("Enter your Social Security Number : ");
									ssn = keyboard.nextLine();
									System.out.print("Enter your Sex (M/F) : ");
									sex = keyboard.nextLine();
									System.out.print("Enter your Email : ");
									email = keyboard.nextLine();
									System.out.print("Enter your Address : ");
									add = keyboard.nextLine();
									if(ssn.length() != 13) {
										System.out.println("SSN Typing Error!");
										break;
									}
									if(fname.length() == 0 || lname.length() == 0) {
										System.out.println("Name Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select count(*) from Manager");
									rs.next();
									temp = rs.getInt(1);
									Random rnd = new Random();
									temp = rnd.nextInt(temp);
									rs = stmt.executeQuery("select ManID from Manager");
									i = 1;
									stmt.executeUpdate("set foreign_key_checks=0");
									while (rs.next()) {
										manID = rs.getInt(1);
										if(temp == 0) i = manID;
										temp--;
										stmt.executeUpdate("insert into User_Man_Manage values ('" + ssn + "','" + manID + "')");
										stmt.executeUpdate("insert into Num_Acc_Manage values ('" + ssn + "','" + manID + "')");
									}
									stmt.executeUpdate("insert into User values ('" + fname + "','" + lname + "','" + ssn + "','" + sex + "','" + email + "','" + add + "','" + i + "')");
									stmt.executeUpdate("insert into NumOfAcc values ('" + ssn + "','0')");
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Done!");
									break;
								case "quit":
									System.out.println("Thank you for using our Bank!");
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from User where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									rs = stmt.executeQuery("select AccNum from Account where UserSSN=" + ssn);
									stmt.executeUpdate("set foreign_key_checks=0");
									totalMon = 0;
									while (rs.next()) {
										acc = rs.getString(1);
										rs2 = stmt.executeQuery("select LoanMoney from Money where AccNum=" + acc);
										rs2.next();
										totalMon += rs2.getInt(1);
										stmt.executeUpdate("delete from Money where AccNum=" + acc);
										stmt.executeUpdate("delete from Mon_Manage where AccNum_Mon=" + acc);
										stmt.executeUpdate("delete from DealInfo where AccNum=" + acc);
										stmt.executeUpdate("delete from Card where AccNum=" + acc);
										stmt.executeUpdate("delete from Account where AccNum=" + acc);
										stmt.executeUpdate("delete from Acc_Manage where AccNum_Acc=" + acc);
										stmt.executeUpdate("delete from LoanInfo where AccNum=" + acc);
									}
									stmt.executeUpdate("delete from NumOfAcc where UserSSN=" + ssn);
									stmt.executeUpdate("delete from Num_Acc_Manage where UserSSN=" + ssn);
									stmt.executeUpdate("delete from User where SSN=" + ssn);
									stmt.executeUpdate("delete from User_Man_Manage where UserSSN=" + ssn);
									rs = stmt.executeQuery("select BankCapital from Bank");
									rs.next();
									bank_cap = rs.getInt(1);
									bank_cap += totalMon;
									stmt.executeUpdate("update Bank set BankCapital=" + bank_cap);
									stmt.executeUpdate("set foreign_key_checks=1");
									System.out.println("Done!");
									break;
								case "help":
									changeCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "view":
						viewCommands();
						end = true;
						while (end) {
							System.out.print("Maria DB [Bank] View > ");
							cmd = keyboard.nextLine();
							switch (cmd) {
								case "users":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from Manager where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("-----------All User's Information-----------");
									System.out.println("| First Name |   Last Name   | Sex | ManID |");
									System.out.println("--------------------------------------------");
									rs = stmt.executeQuery("select FName,LName,Sex,ManID from User order by FName,LName");
									while (rs.next()) {
										System.out.printf("| %10s | %13s | %3s | %5s |\n",rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
									}
									System.out.println("--------------------------------------------");
									rs = stmt.executeQuery("select count(*) from User");
									rs.next();
									System.out.printf("| Total Number Of Users | %16s |\n",rs.getString(1));
									System.out.println("--------------------------------------------\n");
									System.out.println("--------My User's Information-------");
									System.out.println("| First Name |   Last Name   | Sex |");
									System.out.println("------------------------------------");
									rs = stmt.executeQuery("select U.FName,U.LName,U.Sex from User as U,Manager as M  where U.ManID=M.ManID and M.SSN=" + ssn + " order by U.FName,U.LName");
									while (rs.next()) {
										System.out.printf("| %10s | %13s | %3s |\n",rs.getString(1),rs.getString(2),rs.getString(3));
									}
									System.out.println("------------------------------------");
									rs = stmt.executeQuery("select count(*) from User as U,Manager as M  where U.ManID=M.ManID and M.SSN=" + ssn);
									rs.next();
									System.out.printf("| Total Number Of Users | %8s |\n",rs.getString(1));
									System.out.println("------------------------------------");
									break;
								case "loaninfo":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from Manager where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("----------------------------------");
									System.out.println("|    User SSN   | Amount of Loan |");
									System.out.println("----------------------------------");
									rs = stmt.executeQuery("select UserSSN,sum(LoanMoney) from LoanInfo group by UserSSN order by sum(LoanMoney) desc");
									while (rs.next()) {
										System.out.printf("| %13s | %14s |\n",rs.getString(1),rs.getString(2));
									}
									System.out.println("----------------------------------");
									rs = stmt.executeQuery("select sum(LoanMoney) from LoanInfo");
									rs.next();
									System.out.printf("|  Total Loan   |  %13s |\n",rs.getString(1));
									System.out.println("----------------------------------");
									rs = stmt.executeQuery("select BankCapital from Bank");
									rs.next();
									System.out.printf("| Bank Capital  |  %13s |\n",rs.getString(1));
									System.out.println("----------------------------------");
									break;
								case "dealinfo":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from Manager where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.print("Enter the deal date (YYYY-MM-DD) : ");
									date = keyboard.nextLine();
									System.out.println("--------------------- " + date + " Deal --------------------");
									System.out.println("| User Account Number | Deal Account Number | Deal Money |");
									System.out.println("----------------------------------------------------------");
									rs = stmt.executeQuery("select A.AccNum,D.DealAccNum,D.DealMoney from Account as A,DealInfo as D where A.AccNum=D.AccNum and D.DealDate='" + date + "' order by A.AccNum,D.DealAccNum");
									while (rs.next()) {
										System.out.printf("| %19s | %19s | %10s |\n",rs.getString(1),rs.getString(2),rs.getString(3));
									}
									System.out.println("----------------------------------------------------------");
									break;
								case "numofacc":
									System.out.print("Enter your SSN : ");
									ssn = keyboard.nextLine();
									rs = stmt.executeQuery("select count(*) from Manager where SSN=" + ssn);
									rs.next();
									if(rs.getInt(1) == 0) {
										System.out.println("SSN Typing Error!");
										break;
									}
									System.out.println("-------------------------------------");
									System.out.println("|    User SSN   | Number Of Account |");
									System.out.println("-------------------------------------");
									rs = stmt.executeQuery("select UserSSN,NumOfAcc from NumOfAcc order by NumOfAcc");
									while (rs.next()) {
										System.out.printf("| %13s | %17s |\n",rs.getString(1),rs.getString(2));
									}
									System.out.println("-------------------------------------");
									rs = stmt.executeQuery("select sum(NumOfAcc) from NumOfAcc");
									rs.next();
									System.out.printf("| Total Number of Account | %7s |\n",rs.getString(1));
									System.out.println("-------------------------------------");
									break;
								case "help":
									viewCommands();
									break;
								case "back":
									end = false;
									break;
								case "exit":
									end = false;
									fin = false;
									break;
								default:
									System.out.println("Command Error Typing Again!");
							}
						}
						break;
						
					case "help":
						firstCommands();
						break;
						
					case "exit":
						fin = false;
						break;
						
					default:
						System.out.println("Command Error Typing Again!");
						
				}
			}
			System.out.println("Application Terminated");
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(rs != null) rs.close();
				if(rs2 != null) rs2.close();
				if(stmt != null) stmt.close();
				if(con != null) con.close();
                if(keyboard != null) keyboard.close();
			}
			catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
}
