import numpy as np
import glfw
from OpenGL.GL import *
from OpenGL.GLU import *

lpress_check = False; rpress_check = False
prev_xpos = 0.; prev_ypos = 0.
gCamAzi = 15.; gCamElev = 20.; gCamDist = 20.
target = np.array([0.,0.,0.]); eye = np.array([0.,0.,0.]); up = np.array([0.,1.,0.])

# draw a cube of side 2, centered at the origin.
def drawCube():
    glBegin(GL_QUADS)
    glVertex3f( 1.0, 1.0,-1.0)
    glVertex3f(-1.0, 1.0,-1.0)
    glVertex3f(-1.0, 1.0, 1.0)
    glVertex3f( 1.0, 1.0, 1.0)
    
    glVertex3f( 1.0,-1.0, 1.0)
    glVertex3f(-1.0,-1.0, 1.0)
    glVertex3f(-1.0,-1.0,-1.0)
    glVertex3f( 1.0,-1.0,-1.0)
    
    glVertex3f( 1.0, 1.0, 1.0)
    glVertex3f(-1.0, 1.0, 1.0)
    glVertex3f(-1.0,-1.0, 1.0)
    glVertex3f( 1.0,-1.0, 1.0)
    
    glVertex3f( 1.0,-1.0,-1.0)
    glVertex3f(-1.0,-1.0,-1.0)
    glVertex3f(-1.0, 1.0,-1.0)
    glVertex3f( 1.0, 1.0,-1.0)
    
    glVertex3f(-1.0, 1.0, 1.0)
    glVertex3f(-1.0, 1.0,-1.0)
    glVertex3f(-1.0,-1.0,-1.0)
    glVertex3f(-1.0,-1.0, 1.0)
    
    glVertex3f( 1.0, 1.0,-1.0)
    glVertex3f( 1.0, 1.0, 1.0)
    glVertex3f( 1.0,-1.0, 1.0)
    glVertex3f( 1.0,-1.0,-1.0)
    glEnd()

def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([2.,0.,0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,2.,0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0.,0.,0]))
    glVertex3fv(np.array([0.,0.,2.]))
    glEnd()

def drawRigid():
    glBegin(GL_LINES)
    glColor3ub(200, 200, 200)
    for i in range(-8,9):
        if i == 0:
            glVertex3fv(np.array([i,0.,-8.]))
            glVertex3fv(np.array([i,0.,0.]))
            glVertex3fv(np.array([i,0.,2.]))
            glVertex3fv(np.array([i,0.,8.]))
            glVertex3fv(np.array([-8.,0.,i]))
            glVertex3fv(np.array([0.,0.,i]))
            glVertex3fv(np.array([2.,0.,i]))
            glVertex3fv(np.array([8.,0.,i]))
        else:
            glVertex3fv(np.array([i,0.,-8.]))
            glVertex3fv(np.array([i,0.,8.]))
            glVertex3fv(np.array([-8.,0.,i]))
            glVertex3fv(np.array([8.,0.,i]))
    glEnd()

def drawHuman(move_speed):
    
    t = glfw.get_time()
    t *= move_speed
    
    glColor3ub(181, 178, 255)
    
    # chest
    glTranslatef(0,1,0)
    glPushMatrix()
    glRotatef(-2*np.sin(t), 1, 0, 0)
    glPushMatrix()
    glScalef(.6,1,.7)
    drawCube()
    glPopMatrix()
    
    # head
    glPushMatrix()
    glTranslatef(0,1.7,0)
    glScalef(.45,.55,.45)
    drawCube()
    glPopMatrix()
    
    glPopMatrix()
    
    for i in np.array([-1,1]):
        # upper arm
        glPushMatrix()
        glRotatef(-i*5, 1, 0, 0)
        glTranslatef(0,1,0)
        glRotatef(i*25*np.sin(t), 0, 0, 1)
        glTranslatef(0,-1.15,i*1.2)
        glPushMatrix()
        glScalef(.3,1,.3)
        drawCube()
        glPopMatrix()
        
        # fore arm
        glPushMatrix()
        glTranslatef(0,-1,0)
        glRotatef(i*20*np.sin(t)+20, 0, 0, 1)
        glTranslatef(0,-.8,0)
        glPushMatrix()
        glScalef(.25,.65,.25)
        drawCube()
        glPopMatrix()
        
        # hand
        glPushMatrix()
        glTranslatef(0,-1,0)
        glScalef(.2,.15,.2)
        drawCube()
        glPopMatrix()
        
        glPopMatrix()
        glPopMatrix()
    
    # pelvin
    glTranslatef(0,-1.7,0)
    glPushMatrix()
    glRotatef(3*np.sin(t), 1, 0, 0)
    glScalef(.6,.5,.7)
    drawCube()
    glPopMatrix()

    for i in np.array([-1,1]):
        # upper leg
        glPushMatrix()
        glTranslatef(0,-.85,0)
        glRotatef(-i*25*np.sin(t), 0, 0, 1)
        glTranslatef(0,-.75,i*.45)
        glPushMatrix()
        glScalef(.3,1,.3)
        drawCube()
        glPopMatrix()

        # fore leg
        glPushMatrix()
        glTranslatef(0,-.85,0)
        glRotatef(-i*15*np.sin(t)-15, 0, 0, 1)
        glTranslatef(0,-1.25,0)
        glPushMatrix()
        glScalef(.3,1,.3)
        drawCube()
        glPopMatrix()
        
        # foot
        glPushMatrix()
        glTranslatef(.2,-1.2,0)
        glScalef(.5,.2,.3)
        drawCube()
        glPopMatrix()
        
        glPopMatrix()
        glPopMatrix()

def render():
    global gCamAzi, gCamElev, gCamDist, eye, up
    
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE )

    glLoadIdentity()
    
    gluPerspective(60,1,.001,1000)
    
    if np.cos(np.radians(gCamElev)) < 0: up[1] = -1.
    else: up[1] = 1.
    
    eye = np.array([gCamDist*np.cos(np.radians(gCamElev))*np.sin(np.radians(gCamAzi)),gCamDist*np.sin(np.radians(gCamElev)),gCamDist*np.cos(np.radians(gCamElev))*np.cos(np.radians(gCamAzi))])
    
    gluLookAt(eye[0]+target[0],eye[1]+target[1],eye[2]+target[2], target[0],target[1],target[2], up[0],up[1],up[2])
    
    drawRigid()
    drawFrame()
    drawHuman(2)

def cursor_callback(window, xpos, ypos):
    global lpress_check, rpress_check, prev_xpos, prev_ypos, gCamAzi, gCamElev, target, eye, up
    
    if lpress_check == True:
        gCamAzi -= (xpos-prev_xpos)/7*up[1]
        gCamElev += (ypos-prev_ypos)/7
    
    elif rpress_check == True:
        w = eye / np.sqrt(np.dot(eye,eye))
        u = np.cross(up,w) / np.sqrt(np.dot(np.cross(up,w),np.cross(up,w)))
        v = np.cross(w,u)
        target += -(xpos-prev_xpos)/50 * u + (ypos-prev_ypos)/50 * v

    prev_xpos = xpos
    prev_ypos = ypos

def button_callback(window, button, action, mods):
    global lpress_check, rpress_check, prev_xpos, prev_ypos
    
    if button == glfw.MOUSE_BUTTON_LEFT:
        if action == glfw.PRESS:
            lpress_check = True
            temp = glfw.get_cursor_pos(window)
            prev_xpos = temp[0]
            prev_ypos = temp[1]
        elif action == glfw.RELEASE:
            lpress_check = False;

    elif button == glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:
            rpress_check = True
            temp = glfw.get_cursor_pos(window)
            prev_xpos = temp[0]
            prev_ypos = temp[1]
        elif action == glfw.RELEASE:
            rpress_check = False

def scroll_callback(window, xoffset, yoffset):
    global gCamDist
    
    if yoffset < 0 and gCamDist-.2 > 0:
        gCamDist -= .15
    elif yoffset > 0:
        gCamDist += .15

def main():
    if not glfw.init():
        return
    
    window = glfw.create_window(900, 900, "2015004502-class1", None, None)
    if not window:
        glfw.terminate()
        return
    
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)

    glfw.make_context_current(window)

    while not glfw.window_should_close(window):
        glfw.poll_events()

        render()
        
        glfw.swap_buffers(window)
    
    glfw.terminate()

if __name__ == "__main__":
    main()
