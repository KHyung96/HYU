import numpy as np
import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.arrays import vbo
import ctypes

lpress_check = False; rpress_check = False
prev_xpos = 0.; prev_ypos = 0.
gCamAzi = 15.; gCamElev = 20.; gCamDist = 20.
target = np.array([0.,0.,0.]); eye = np.array([0.,0.,0.]); up = np.array([0.,1.,0.])
varr3 = np.array([[]],'float32'); varr4 = np.array([[]],'float32')
varr3_sm = np.array([[]],'float32'); varr4_sm = np.array([[]],'float32')
wire_mode = False; smooth_mode = False

def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([2.,0.,0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,2.,0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0.,0.,0]))
    glVertex3fv(np.array([0.,0.,2.]))
    glEnd()

def drawRigid():
    glBegin(GL_LINES)
    glColor3ub(200, 200, 200)
    for i in range(-8,9):
        if i == 0:
            glVertex3fv(np.array([i,0.,-8.]))
            glVertex3fv(np.array([i,0.,0.]))
            glVertex3fv(np.array([i,0.,2.]))
            glVertex3fv(np.array([i,0.,8.]))
            glVertex3fv(np.array([-8.,0.,i]))
            glVertex3fv(np.array([0.,0.,i]))
            glVertex3fv(np.array([2.,0.,i]))
            glVertex3fv(np.array([8.,0.,i]))
        else:
            glVertex3fv(np.array([i,0.,-8.]))
            glVertex3fv(np.array([i,0.,8.]))
            glVertex3fv(np.array([-8.,0.,i]))
            glVertex3fv(np.array([8.,0.,i]))
    glEnd()

def drawObject():
    global varr3, varr4, varr3_sm, varr4_sm, smooth_mode
    
    if smooth_mode == False:
        now3 = varr3; now4 = varr4
    else:
        now3 = varr3_sm; now4 = varr4_sm

    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    glNormalPointer(GL_FLOAT, 6*now3.itemsize, now3)
    glVertexPointer(3, GL_FLOAT, 6*now3.itemsize, ctypes.c_void_p(now3.ctypes.data + 3*now3.itemsize))
    glDrawArrays(GL_TRIANGLES, 0, int(now3.size/6))
    glNormalPointer(GL_FLOAT, 6*now4.itemsize, now4)
    glVertexPointer(3, GL_FLOAT, 6*now4.itemsize, ctypes.c_void_p(now4.ctypes.data + 3*now4.itemsize))
    glDrawArrays(GL_QUADS, 0, int(now4.size/6))

def render():
    global gCamAzi, gCamElev, gCamDist, eye, up, wire_mode
    
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    if wire_mode == True: glPolygonMode( GL_FRONT_AND_BACK, GL_LINE )
    else: glPolygonMode( GL_FRONT_AND_BACK, GL_FILL )
    
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    
    gluPerspective(60,1,.001,100000)
    
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    
    if np.cos(np.radians(gCamElev)) < 0: up[1] = -1.
    else: up[1] = 1.
    
    eye = np.array([gCamDist*np.cos(np.radians(gCamElev))*np.sin(np.radians(gCamAzi)),gCamDist*np.sin(np.radians(gCamElev)),gCamDist*np.cos(np.radians(gCamElev))*np.cos(np.radians(gCamAzi))])
    
    gluLookAt(eye[0]+target[0],eye[1]+target[1],eye[2]+target[2], target[0],target[1],target[2], up[0],up[1],up[2])
    
    drawRigid()
    drawFrame()
    
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)
    glEnable(GL_RESCALE_NORMAL)
    
    LightColor1 = (.8,.8,1.,1.)
    LightColor2 = (.9,.9,.5,1.)
    ambientLightColor = (.1,.1,.1,1.)
    
    glLightfv(GL_LIGHT0, GL_POSITION, (6.,5.,6.,0.))
    
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, LightColor1)
    glLightfv(GL_LIGHT0, GL_SPECULAR, LightColor1)
    
    glLightfv(GL_LIGHT1, GL_POSITION, (-6.,5.,-6.,0.))
    
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLightColor)
    glLightfv(GL_LIGHT1, GL_DIFFUSE, LightColor2)
    glLightfv(GL_LIGHT1, GL_SPECULAR, LightColor2)

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, (1.,1.,1.,1.))
    
    drawObject()

    glDisable(GL_LIGHTING)

def key_callback(window, key, scancode, action, mods):
    global wire_mode, smooth_mode
    
    if action==glfw.PRESS:
        if key==glfw.KEY_Z:
            if wire_mode == False: wire_mode = True
            else: wire_mode = False
        elif key==glfw.KEY_S:
            if smooth_mode == False: smooth_mode = True
            else: smooth_mode = False

def cursor_callback(window, xpos, ypos):
    global lpress_check, rpress_check, prev_xpos, prev_ypos, gCamAzi, gCamElev, target, eye, up
    
    if lpress_check == True:
        gCamAzi -= (xpos-prev_xpos)/7*up[1]
        gCamElev += (ypos-prev_ypos)/7
    
    elif rpress_check == True:
        w = eye / np.sqrt(np.dot(eye,eye))
        u = np.cross(up,w) / np.sqrt(np.dot(np.cross(up,w),np.cross(up,w)))
        v = np.cross(w,u)
        target += -(xpos-prev_xpos)/50 * u + (ypos-prev_ypos)/50 * v

    prev_xpos = xpos
    prev_ypos = ypos

def button_callback(window, button, action, mods):
    global lpress_check, rpress_check, prev_xpos, prev_ypos
    
    if button == glfw.MOUSE_BUTTON_LEFT:
        if action == glfw.PRESS:
            lpress_check = True
            temp = glfw.get_cursor_pos(window)
            prev_xpos = temp[0]
            prev_ypos = temp[1]
        elif action == glfw.RELEASE:
            lpress_check = False;

    elif button == glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:
            rpress_check = True
            temp = glfw.get_cursor_pos(window)
            prev_xpos = temp[0]
            prev_ypos = temp[1]
        elif action == glfw.RELEASE:
            rpress_check = False

def scroll_callback(window, xoffset, yoffset):
    global gCamDist
    
    if gCamDist+yoffset/6 < .2:
        gCamDist = .2
    else:
        gCamDist += yoffset/6

def drop_callback(window, path):
    global varr3, varr4, varr3_sm, varr4_sm
    
    parr = []; narr = []; iarr3 = []; iarr4 = []; iarr3_n = []; iarr4_n = []
    count = count_3v = count_4v = count_3f = 0
    
    fp = open(path[0], 'r')
    
    while True:
        line = fp.readline()
        if line == '': break
        
        if line[0:2] == "v ":
            element = line.split(); temp = []
            for i in range(1,4):
                temp += [float(element[i])]
            parr.append(temp)

        elif line[0:3] == "vn ":
            element = line.split(); temp = []
            for i in range(1,4):
                temp += [float(element[i])]
            narr.append(temp)

        elif line[0:2] == "f ":
            count += 1; element = line.split()
            
            if len(element) == 5:
                count_4v += 1
                temp = []; temp2 = []
                for i in range(1,5):
                    element2 = element[i].split('/')
                    temp += [int(element2[0])-1]
                    if len(element2) < 3 or element2[-1] == '': temp2 += [0]
                    else: temp2 += [int(element2[-1])]
                iarr4.append(temp)
                iarr4_n.append(temp2)
        
            else:
                count_3v += 1
                if len(element) == 4: count_3f += 1
                temp = []; temp2 = []
                for i in range(1,4):
                    element2 = element[i].split('/')
                    temp += [int(element2[0])-1]
                    if len(element2) < 3 or element2[-1] == '': temp2 += [0]
                    else: temp2 += [int(element2[-1])]
                iarr3.append(temp)
                iarr3_n.append(temp2)

    varr3 = np.empty([count_3v*6,3],'float32')
    varr4 = np.empty([count_4v*8,3],'float32')

    for i in range(count_3v):
        for j in range(0,3):
            if iarr3_n[i][j] == 0: varr3[i*6+j*2] = [0.,0.,0.]
            else: varr3[i*6+j*2] = narr[iarr3_n[i][j]-1]
            varr3[i*6+j*2+1] = parr[iarr3[i][j]]
    for i in range(count_4v):
        for j in range(0,4):
            if iarr4_n[i][j] == 0: varr4[i*8+j*2] = [0.,0.,0.]
            else: varr4[i*8+j*2] = narr[iarr4_n[i][j]-1]
            varr4[i*8+j*2+1] = parr[iarr4[i][j]]

    nvecs = np.zeros((len(parr),3),'float32')
    for i in range(count_3v):
        now = np.cross(np.subtract(parr[iarr3[i][1]],parr[iarr3[i][0]]),np.subtract(parr[iarr3[i][2]],parr[iarr3[i][1]]))
        for j in range(0,3):
            nvecs[iarr3[i][j]] += now
    for i in range(count_4v):
        now = np.cross(np.subtract(parr[iarr4[i][1]],parr[iarr4[i][0]]),np.subtract(parr[iarr4[i][3]],parr[iarr4[i][0]]))
        for j in range(0,4):
            nvecs[iarr4[i][j]] += now
    for i in range(len(parr)):
        if np.dot(nvecs[i],nvecs[i]) != 0.:
            nvecs[i] /= np.sqrt(np.dot(nvecs[i],nvecs[i]))

    varr3_sm = np.empty([count_3v*6,3],'float32')
    varr4_sm = np.empty([count_4v*8,3],'float32')

    for i in range(count_3v):
        for j in range(0,3):
            varr3_sm[i*6+j*2] = nvecs[iarr3[i][j]]
            varr3_sm[i*6+j*2+1] = parr[iarr3[i][j]]
    for i in range(count_4v):
        for j in range(0,4):
            varr4_sm[i*8+j*2] = nvecs[iarr4[i][j]]
            varr4_sm[i*8+j*2+1] = parr[iarr4[i][j]]

    print("File name =",path[0].split('/')[-1])
    print("Total number of faces =",count)
    print("Number of faces with 3 vertices =",count_3f)
    print("Number of faces with 4 vertices =",count_4v)
    print("Number of faces with more than 4 vertices =",count-count_3f-count_4v,"\n")
    fp.close()

def main():
    if not glfw.init():
        return
    
    window = glfw.create_window(900, 900, "2015004502-class2", None, None)
    if not window:
        glfw.terminate()
        return
    
    glfw.set_key_callback(window, key_callback)
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.set_drop_callback(window, drop_callback)

    glfw.make_context_current(window)

    while not glfw.window_should_close(window):
        glfw.poll_events()
        render()
        glfw.swap_buffers(window)
    
    glfw.terminate()

if __name__ == "__main__":
    main()
