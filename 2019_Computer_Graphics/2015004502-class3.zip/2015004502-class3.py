import numpy as np
import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.arrays import vbo
import ctypes

lpress_check = False; rpress_check = False
prev_xpos = 0.; prev_ypos = 0.
gCamAzi = 15.; gCamElev = 20.; gCamDist = 20.
target = np.array([0.,0.,0.]); eye = np.array([0.,0.,0.]); up = np.array([0.,1.,0.])
stack = []; offset = []; channel = []; position = []; varr = []; iarr = []
frame_num = 0; frame = 0; max_dist = 0.; animation_mode = False

def drawFrame():
    glBegin(GL_LINES)
    glColor3ub(255, 0, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([2.,0.,0.]))
    glColor3ub(0, 255, 0)
    glVertex3fv(np.array([0.,0.,0.]))
    glVertex3fv(np.array([0.,2.,0.]))
    glColor3ub(0, 0, 255)
    glVertex3fv(np.array([0.,0.,0]))
    glVertex3fv(np.array([0.,0.,2.]))
    glEnd()

def drawRigid():
    glBegin(GL_LINES)
    glColor3ub(200, 200, 200)
    for i in range(-8,9):
        if i == 0:
            glVertex3fv(np.array([i,0.,-8.]))
            glVertex3fv(np.array([i,0.,0.]))
            glVertex3fv(np.array([i,0.,2.]))
            glVertex3fv(np.array([i,0.,8.]))
            glVertex3fv(np.array([-8.,0.,i]))
            glVertex3fv(np.array([0.,0.,i]))
            glVertex3fv(np.array([2.,0.,i]))
            glVertex3fv(np.array([8.,0.,i]))
        else:
            glVertex3fv(np.array([i,0.,-8.]))
            glVertex3fv(np.array([i,0.,8.]))
            glVertex3fv(np.array([-8.,0.,i]))
            glVertex3fv(np.array([8.,0.,i]))
    glEnd()

def createArray():
    global varr, iarr
    varr = np.array([
                     (-0.5773502691896258, 0.5773502691896258, 0.5773502691896258),
                     ( -1 ,  1 ,  1 ), # v0
                     (0.8164965809277261, 0.4082482904638631, 0.4082482904638631),
                     (  1 ,  1 ,  1 ), # v1
                     (0.4082482904638631, -0.4082482904638631, 0.8164965809277261),
                     (  1 , -1 ,  1 ), # v2
                     (-0.4082482904638631, -0.8164965809277261, 0.4082482904638631),
                     ( -1 , -1 ,  1 ), # v3
                     (-0.4082482904638631, 0.4082482904638631, -0.8164965809277261),
                     ( -1 ,  1 ,  0 ), # v4
                     (0.4082482904638631, 0.8164965809277261, -0.4082482904638631),
                     (  1 ,  1 ,  0 ), # v5
                     (0.5773502691896258, -0.5773502691896258, -0.5773502691896258),
                     (  1 , -1 ,  0 ), # v6
                     (-0.8164965809277261, -0.4082482904638631, -0.4082482904638631),
                     ( -1 , -1 ,  0 ), # v7
                    ], 'float32')
    iarr = np.array([
                     (0,2,1),
                     (0,3,2),
                     (4,5,6),
                     (4,6,7),
                     (0,1,5),
                     (0,5,4),
                     (3,6,2),
                     (3,7,6),
                     (1,2,6),
                     (1,6,5),
                     (0,7,3),
                     (0,4,7),
                    ])

def drawCube(now):
    global varr, iarr, max_dist
    
    temp = np.sqrt(np.dot(-now,-now))
    if temp != 0.: w = -now/temp
    else:  w = np.array([0.,0.,0.])
    temp = np.sqrt(np.dot(np.cross([0,1,0],w),np.cross([0,1,0],w)))
    if temp != 0.: u = np.cross([0,1,0],w)/temp
    else: u = np.array([0.,0.,0.])
    v = np.cross(w,u)
    
    M = np.identity(4)
    M[0:3,0] = u
    M[0:3,1] = v
    M[0:3,2] = w
    
    glMultMatrixf(M.T)
    glScalef(max_dist*.03, max_dist*.03, -np.sqrt(np.dot(now,now)))

    glEnableClientState(GL_VERTEX_ARRAY)
    glEnableClientState(GL_NORMAL_ARRAY)
    glNormalPointer(GL_FLOAT, 6*varr.itemsize, varr)
    glVertexPointer(3, GL_FLOAT, 6*varr.itemsize, ctypes.c_void_p(varr.ctypes.data + 3*varr.itemsize))
    glDrawElements(GL_TRIANGLES, iarr.size, GL_UNSIGNED_INT, iarr)

def drawObject():
    global stack, offset, channel, position, animation_mode, frame_num

    count = offnow = chnow = 0
    
    for i in range(len(stack)):
        if stack[i] == 1:
            glPushMatrix()
            glPushMatrix()
            drawCube(np.array(offset[offnow]))
            glPopMatrix()
            glTranslatef(offset[offnow][0], offset[offnow][1], offset[offnow][2])
            offnow += 1
            if animation_mode == True:
                for j in range(len(channel[chnow])):
                    if channel[chnow][j] == 1:
                        glRotatef(position[frame_num][count+j], 1,0,0)
                    elif channel[chnow][j] == 2:
                        glRotatef(position[frame_num][count+j], 0,1,0)
                    elif channel[chnow][j] == 3:
                        glRotatef(position[frame_num][count+j], 0,0,1)
                    elif channel[chnow][j] == 4:
                        glTranslatef(position[frame_num][count+j], 0, 0)
                    elif channel[chnow][j] == 5:
                        glTranslatef(0, position[frame_num][count+j], 0)
                    elif channel[chnow][j] == 6:
                        glTranslatef(0, 0, position[frame_num][count+j])
                count += len(channel[chnow])
                chnow += 1
        else:
            glPopMatrix()

def render():
    global gCamAzi, gCamElev, gCamDist, eye, up
    
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
    glEnable(GL_DEPTH_TEST)
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL )
    
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    
    gluPerspective(60,1,.001,100000)
    
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    
    if np.cos(np.radians(gCamElev)) < 0: up[1] = -1.
    else: up[1] = 1.
    
    eye = np.array([gCamDist*np.cos(np.radians(gCamElev))*np.sin(np.radians(gCamAzi)),gCamDist*np.sin(np.radians(gCamElev)),gCamDist*np.cos(np.radians(gCamElev))*np.cos(np.radians(gCamAzi))])
    
    gluLookAt(eye[0]+target[0],eye[1]+target[1],eye[2]+target[2], target[0],target[1],target[2], up[0],up[1],up[2])
    
    drawRigid()
    drawFrame()
    
    glEnable(GL_LIGHTING)
    glEnable(GL_LIGHT0)
    glEnable(GL_LIGHT1)
    glEnable(GL_RESCALE_NORMAL)
    
    LightColor1 = (.8,.8,1.,1.)
    LightColor2 = (.9,.9,.5,1.)
    ambientLightColor = (.1,.1,.1,1.)
    
    glLightfv(GL_LIGHT0, GL_POSITION, (6.,5.,6.,0.))
    
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLightColor)
    glLightfv(GL_LIGHT0, GL_DIFFUSE, LightColor1)
    glLightfv(GL_LIGHT0, GL_SPECULAR, LightColor1)
    
    glLightfv(GL_LIGHT1, GL_POSITION, (-6.,5.,-6.,0.))
    
    glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLightColor)
    glLightfv(GL_LIGHT1, GL_DIFFUSE, LightColor2)
    glLightfv(GL_LIGHT1, GL_SPECULAR, LightColor2)

    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, (1.,1.,1.,1.))
    
    drawObject()

    glDisable(GL_LIGHTING)

def key_callback(window, key, scancode, action, mods):
    global animation_mode, frame_num
    
    if action==glfw.PRESS:
        if key==glfw.KEY_SPACE:
            if animation_mode == False: animation_mode = True
            else: animation_mode = False
            frame_num = 0

def cursor_callback(window, xpos, ypos):
    global lpress_check, rpress_check, prev_xpos, prev_ypos, gCamAzi, gCamElev, target, eye, up
    
    if lpress_check == True:
        gCamAzi -= (xpos-prev_xpos)/7*up[1]
        gCamElev += (ypos-prev_ypos)/7
    
    elif rpress_check == True:
        w = eye / np.sqrt(np.dot(eye,eye))
        u = np.cross(up,w) / np.sqrt(np.dot(np.cross(up,w),np.cross(up,w)))
        v = np.cross(w,u)
        target += -(xpos-prev_xpos)/50 * u + (ypos-prev_ypos)/50 * v

    prev_xpos = xpos
    prev_ypos = ypos

def button_callback(window, button, action, mods):
    global lpress_check, rpress_check, prev_xpos, prev_ypos
    
    if button == glfw.MOUSE_BUTTON_LEFT:
        if action == glfw.PRESS:
            lpress_check = True
            temp = glfw.get_cursor_pos(window)
            prev_xpos = temp[0]
            prev_ypos = temp[1]
        elif action == glfw.RELEASE:
            lpress_check = False

    elif button == glfw.MOUSE_BUTTON_RIGHT:
        if action == glfw.PRESS:
            rpress_check = True
            temp = glfw.get_cursor_pos(window)
            prev_xpos = temp[0]
            prev_ypos = temp[1]
        elif action == glfw.RELEASE:
            rpress_check = False

def scroll_callback(window, xoffset, yoffset):
    global gCamDist
    
    if gCamDist+yoffset/6 < .2:
        gCamDist = .2
    else:
        gCamDist += yoffset/6

def drop_callback(window, path):
    global stack, offset, channel, position, animation_mode, frame, max_dist
    
    fp = open(path[0], 'r')
    
    # false : HEIRARCHY, true : MOTION
    mode_check = False
    animation_mode = False
    
    stack = []; offset = []; channel = []; position = []; jnames = []
    count_joint = tot_chan = frame = 0
    ftime = max_dist = 0.
    
    while True:
        line = fp.readline()
        if line == '': break
        
        line = line.split()
        
        if line[0] == "HIERARCHY":
            mode_check = False
        elif line[0] == "MOTION":
            mode_check = True
        elif mode_check == False:
            if line[0] == "ROOT" or line[0] == "JOINT":
                count_joint += 1
                jnames.append(line[1])
            elif line[0] == "End":
                channel.append([])
            elif line[0] == "OFFSET":
                offset.append([float(line[1]), float(line[2]), float(line[3])])
                if max_dist < np.sqrt(np.dot(offset[len(offset)-1],offset[len(offset)-1])):
                    max_dist = np.sqrt(np.dot(offset[len(offset)-1],offset[len(offset)-1]))
            elif line[0] == "CHANNELS":
                tot_chan += int(line[1])
                temp = []
                for i in range(int(line[1])):
                    if line[i+2].lower() == "xposition":
                        temp.append(4)
                    elif line[i+2].lower() == "yposition":
                        temp.append(5)
                    elif line[i+2].lower() == "zposition":
                        temp.append(6)
                    elif line[i+2].lower() == "xrotation":
                        temp.append(1)
                    elif line[i+2].lower() == "yrotation":
                        temp.append(2)
                    elif line[i+2].lower() == "zrotation":
                        temp.append(3)
                channel.append(temp)
            elif line[0] == "{":
                stack.append(1)
            elif line[0] == "}":
                stack.append(-1)
        else:
            if line[0] == "Frames:":
                frame = int(line[1])
            elif line[0] == "Frame" and line[1] == "Time:":
                ftime = float(line[2])
            else:
                temp = []
                for i in range(tot_chan):
                    temp.append(float(line[i]))
                position.append(temp)
    
    print("File name =", path[0].split('/')[-1])
    print("Number of frames =", frame)
    print("FPS (which is 1/FrameTime) =", 1/ftime)
    print("Number of joints =", count_joint)
    print("List of all joint names = ", end = '')
    for i in range(len(jnames)):
        if i == len(jnames)-1:
            print(jnames[i], '\n')
        else:
            print(jnames[i], ", ", end = '')
    fp.close()

def main():
    if not glfw.init():
        return
    
    window = glfw.create_window(900, 900, "2015004502-class3", None, None)
    if not window:
        glfw.terminate()
        return
    
    glfw.set_key_callback(window, key_callback)
    glfw.set_cursor_pos_callback(window, cursor_callback)
    glfw.set_mouse_button_callback(window, button_callback)
    glfw.set_scroll_callback(window, scroll_callback)
    glfw.set_drop_callback(window, drop_callback)

    glfw.make_context_current(window)

    glfw.swap_interval(1)

    global frame_num, frame

    createArray()

    while not glfw.window_should_close(window):
        glfw.poll_events()
        render()
        frame_num += 1
        if frame_num >= frame:
            frame_num = 0
        glfw.swap_buffers(window)
    
    glfw.terminate()

if __name__ == "__main__":
    main()
